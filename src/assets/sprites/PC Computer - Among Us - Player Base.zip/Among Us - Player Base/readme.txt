Sprites ripped by JordanTRS and JJ314

JordanTrs's Channel: https://www.youtube.com/channel/UCGMsFdGMBgjm5zYMUohTLvg